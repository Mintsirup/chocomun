#include <pxa255.c>
#include <time.h>
#include <gpio.h>
#include <stdio.h>
#include <string.h>

inst main(viod)
{
	while(1){
		printf("hello world\n");
		msleep(1000);
	}
}
